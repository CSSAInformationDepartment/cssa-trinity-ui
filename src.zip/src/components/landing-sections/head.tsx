import React, { Component } from 'react'
import BaseSection from  './base';

export class HeadSection extends Component {
    render() {
        return (
            <BaseSection 
                id="head" 
                title= ""
                bgColor= "light">
                    
            </BaseSection>
        )
    }
}
