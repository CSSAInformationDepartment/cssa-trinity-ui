import React, { Component } from 'react'

export default class MemberWelcome extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
