import React, { Component } from 'react'
import {Link} from 'react-router-dom'

interface ILoginState {

}

export default class Login extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
